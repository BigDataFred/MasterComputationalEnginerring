source("aritmod/invmod.R")
source("afin/cifafin.R")

decafin <- function(alfabeto, criptograma, k,  a, b)
# Entrada: alfabeto 
#          criptograma: mensaje cifrado partiendo el mensaje en k-gramas y
#          con una transformación afín de clave (a, b)
#          k, a, b (enteros, k>0, a primo relativo con N=length(alfabeto))
# Salida:  mensaje en claro
  {
    N <- length(alfabeto)
    ap <- invmod(a,N^{k})
    bp <- -b*ap

    M <- cifafin(alfabeto, criptograma, k,  ap, bp)
    return(M)
  }
